﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {

            int[,] numeros = new int[3, 5];

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++) {
                    if((i+j) % 2 == 0)
                        numeros[i, j] = 1;
                    else
                        numeros[i, j] = 0;
                    Console.WriteLine("[{0},{1}] = {2}", i, j, numeros[i, j]);
                }
            }

            Console.ReadKey();
        }
    }
}

 

