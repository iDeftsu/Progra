﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int[,] numeros = new int[3, 5];

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    numeros[i, j] = random.Next(10);
                    Console.WriteLine("{0} ", numeros[i, j]);

                    Console.WriteLine(" ");
                }

            }
            Console.ReadKey();
        }
    }
}
                