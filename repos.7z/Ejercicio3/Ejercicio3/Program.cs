﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int suma, producto;

            int[,] numeros = new int[3, 5];

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 5; j++)
                    numeros[i, j] = random.Next(10);
            Console.WriteLine("{0} ", numeros[i, j]);
        }
            Console.WriteLine(" ");
            }
            for (int i = 0; i< 3; i++)
            {
                suma = 0;
                for (int j = 0; j< 5; j++)
                    suma += numeros[i, j];
                Console.WriteLine("El producto de la columna {0} es: {1}", i + 1, suma);

            }

            for (int j = 0; j < 5; j++)
            {
                producto = 0;
                for (int i = 0; i < 3; j++)
                    producto += numeros[i, j];
                Console.WriteLine("El producto de la columna {0} es: {1}", i + 1, producto);
            }
            Console.ReadKey();
}
}
}


